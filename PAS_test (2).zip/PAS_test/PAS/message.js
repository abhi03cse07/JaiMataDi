function check(i)
{
switch(i)
{
case 1: alert("Please enter Quality Of Work field ");
 break;
case 2: alert("Please enter Quantity Of Work field ");
 break;
case 3: alert("Please enter Dependibility field ");
 break;
case 4: alert("Please enter Job Knowledge field ");
 break;
case 5: alert("Please enter Interest,Initiative And Responsibility field ");
 break;
case 6: alert("Please enter Spoken And Written Communication field ");
 break;
case 7: alert("Please enter Discipline And Time Control Field ");
 break;
case 8: alert("Please enter Creativity,Intelligence And Mental Calibre field ");
 break;
case 9: alert("Please enter Interpersonal Relationship And Adapability field ");
 break;
case 10: alert("Please Enter Team Work field ");
 break;
case 11: alert("Please enter Leadership field ");
 break;
case 12: alert("Please enter Planning And Organizing field ");
 break;
case 13: alert("Please enter Correct Values ");
 break;
}
}


