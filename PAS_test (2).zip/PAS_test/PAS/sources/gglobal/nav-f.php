<style>.hide{display:none !important;}</style>
<!--Main Navigation-->
<header class="myim-header">

<nav class="navbar navbar-expand-md navbar-light double-nav scrolling-navbar">
    <a class="navbar-brand" href="#">
        <img class="" src="http://www.myimss.work/logos/logo_myim_white.png" width="100px;" style="padding-left:10px;">
        &nbsp;<span style="font-size:22px;font-weight:200;color:white;"><?php echo $appname; ?></span>
    </a>
    <ul class="nav navbar-nav nav-flex-icons ml-auto">
        <li class="nav-item avatar dropdown">
            <a class="nav-link dropdown-toggle waves-effect waves-light" id="navbarDropdownMenuLink-5" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-th white-text" style="font-size:150%;"></i> &nbsp;
            </a>
            <div class="dropdown-menu dropdown-menu-right dropdown-secondary" style="font-size:85%;border: 1px solid #dadada;box-shadow: 0px 2px 2px 2px #f5e4e4;" aria-labelledby="navbarDropdownMenuLink-5">
			
				<?php 
					$productList = ImssUtilities::getProductList();
					for ($x = 0; $x < count($productList); $x++) {
						
						if($productList[$x]->id == $PRODUCT_ID){
							$style="background-color: #6fffeb;";
						} else {
							$style="";
						}
						
						echo '<a class="dropdown-item waves-effect waves-light" style="'.$style.'" href="'.$productList[$x]->url.'" ><i class="fa '.$productList[$x]->menuIcon.'"></i> &nbsp; '.$productList[$x]->productName.'</a>';
						
					} 
				?>
            </div>
        </li>
        <!-- <li class="nav-item avatar dropdown">
            <a class="nav-link dropdown-toggle waves-effect waves-light" id="navbarDropdownMenuLink-5" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fa fa-user-circle" style="font-size:150%;"></i> &nbsp;

            </a>
            <div class="dropdown-menu dropdown-menu-right dropdown-secondary" style="font-size:85%;border: 1px solid #dadada;box-shadow: 0px 2px 2px 2px #f5e4e4;" aria-labelledby="navbarDropdownMenuLink-5">
                <a class="dropdown-item waves-effect waves-light" href="//apps.myimss.work/login">Login</a>
                <a class="dropdown-item waves-effect waves-light" href="//apps.myimss.work/feedback" target="_blank">Feedback</a>
            </div>
        </li> -->
        <li class="nav-item avatar dropdown">
            <a class="nav-link dropdown-toggle waves-effect waves-light" id="navbarDropdownMenuLink-5" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fa fa-user-circle white-text" style="font-size:150%;"></i>
            </a>
            <div class="dropdown-menu dropdown-menu-right dropdown-secondary" aria-labelledby="navbarDropdownMenuLink-5">
				
				
			
                <p class="dropdown-item waves-effect waves-light" style="text-align:center;font-size:75%;line-height: 95%;border-bottom: #cdcdcd 1px solid;">
				
				
				
				<img src="<?php echo ImssUtilities::getUserAvatar(); ?>" style="max-width:60px;" class="rounded-circle z-depth-0" alt="avatar image"><br>
                    <span style="font-weight:bold;"><?php echo ImssUtilities::getUserFullName(); ?></span><br>
                    <span style="font-size:90%;"><br><?php echo ImssUtilities::getUserEmail(); ?></span>
                </p>
                <!--<a class="dropdown-item waves-effect waves-light" href="#">Profile</a>
                <a class="dropdown-item waves-effect waves-light" href="#">Manage Account</a>
                <a class="dropdown-item waves-effect waves-light" href="#">Feedback</a> -->
                <a class="dropdown-item waves-effect waves-light" href="?action=logout">Logout</a>
            </div>
        </li>
    </ul>
</nav>

</header>
<!--Main Navigation-->
