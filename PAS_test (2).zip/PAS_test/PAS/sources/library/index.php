
<?php  include '../gglobal/configurations.php'; ?>

<?php
$URL_APP_BASE = $LIBRARY_URL_APP_BASE ;
$PRODUCT_ID = $LIBRARY_PRODUCT_ID ;
$PRODUCT_KEY = $LIBRARY_PRODUCT_KEY ;
?>

<?php  include '../gglobal/utilities.php'; ?>
<?php  include '../gglobal/validate.php'; ?>



<?php $appname = "Library - Digital Assets, Resources & Knowledge"; ?>
<?php  include '../gglobal/head-top.php'; ?>
    <?php  include '../gglobal/nav-f.php'; ?>
	<main class="container py-4">
		<ul class="nav nav-tabs nav-justified">
			<li class="btn btn-unique px-2 py-2 "><a class="white-text" data-toggle="tab" href="#pane111" role="tab">All</a></li>
			<li class="btn btn-unique px-2 py-2 "><a class="white-text" data-toggle="tab" href="#panel12" role="tab">Logos</a></li>
			<li class="btn btn-unique px-2 py-2 "><a class="white-text" data-toggle="tab" href="#panel13" role="tab">Fonts</a></li>
			<li class="btn btn-unique px-2 py-2 "><a class="white-text" data-toggle="tab" href="#panel14" role="tab">Brochures</a></li>
			<li class="btn btn-unique px-2 py-2 "><a class="white-text" data-toggle="tab" href="#panel15" role="tab">Templates</a></li>
			<li class="btn btn-unique px-2 py-2 "><a class="white-text" data-toggle="tab" href="#panel16" role="tab">Talks</a></li>
			<li class="btn btn-unique px-2 py-2 "><a class="white-text" data-toggle="tab" href="#pane222" role="tab">for Review</a></li>
		</ul>
		<!-- Tab panels -->
		<div class="tab-content">
			<!--Panel 1-->
			<div class="tab-pane fade in show active" id="panel11" role="tabpanel">
				<br>
				<p>
				Digital assets including brand assets, collaterals, brochures, logos, fonts and other development libraries with top-of-the-line CDN. You can directly make calls to these URLs from any of your apps.
				</p>
				<div class="" id="show-data">
					<?php
						/* PARSE JSON FOR META */
						$json_resources_file = file_get_contents('https://www.googleapis.com/storage/v1/b/files.imss.work/o');
						$jfo_resources = json_decode($json_resources_file);
						$resourcesfiledata = $jfo_resources->items;
						foreach ($resourcesfiledata as $resource_file) {
							$resourcefile_bucket=$resource_file->bucket;
							$resourcefile_name=$resource_file->name;
							$resourcefile_link = 'http://'.$resourcefile_bucket.'/'.$resourcefile_name;
							$resourcefile_metatitle=$resource_file->metadata->metatitle;
							if (substr($resourcefile_link, -1)!='/'){
					?>
							<ul>
								<li>
									<a class="blue-text" href="<?php echo $resourcefile_link; ?>">
										<?php
											if (isset($resourcefile_metatitle))
												echo $resourcefile_metatitle;
											else
												echo $resourcefile_link;
										?>
									</a>
								</li>
							</ul>
					<?php
							}
						}
					?>
				</div>
			</div>
			<!--/.Panel 1-->
			<!--Panel 2-->
			<div class="tab-pane fade" id="panel12" role="tabpanel">
				<br>
				<div class="" id="show-data">
					<?php
						/* PARSE JSON FOR META */
						$json_resources_file = file_get_contents('https://www.googleapis.com/storage/v1/b/files.imss.work/o?prefix=logos/');
						$jfo_resources = json_decode($json_resources_file);
						$resourcesfiledata = $jfo_resources->items;
						foreach ($resourcesfiledata as $resource_file) {
							$resourcefile_bucket=$resource_file->bucket;
							$resourcefile_name=$resource_file->name;
							$resourcefile_link = 'http://'.$resourcefile_bucket.'/'.$resourcefile_name;
							$resourcefile_metatitle=$resource_file->metadata->metatitle;
							if (substr($resourcefile_link, -1)!='/'){
					?>
							<ul>
								<li>
									<a href="<?php echo $resourcefile_link; ?>">
										<?php
											if (isset($resourcefile_metatitle))
												echo $resourcefile_metatitle;
											else
												echo $resourcefile_link;
										?>
									</a>
								</li>
							</ul>
					<?php
							}
						}
					?>
				</div>
			</div>
			<!--/.Panel 2-->
			<!--Panel 3-->
			<div class="tab-pane fade" id="panel13" role="tabpanel">
				<br>
				<div class="" id="show-data">
					<?php
						/* PARSE JSON FOR META */
						$json_resources_file = file_get_contents('https://www.googleapis.com/storage/v1/b/files.imss.work/o?prefix=assets/fonts/');
						$jfo_resources = json_decode($json_resources_file);
						$resourcesfiledata = $jfo_resources->items;
						foreach ($resourcesfiledata as $resource_file) {
							$resourcefile_bucket=$resource_file->bucket;
							$resourcefile_name=$resource_file->name;
							$resourcefile_link = 'http://'.$resourcefile_bucket.'/'.$resourcefile_name;
							$resourcefile_metatitle=$resource_file->metadata->metatitle;
							if (substr($resourcefile_link, -1)!='/'){
					?>
							<ul>
								<li>
									<a href="<?php echo $resourcefile_link; ?>">
										<?php
											if (isset($resourcefile_metatitle))
												echo $resourcefile_metatitle;
											else
												echo $resourcefile_link;
										?>
									</a>
								</li>
							</ul>
					<?php
							}
						}
					?>
				</div>
			</div>
			<!--/.Panel 3-->
			<!--Panel 4-->
			<div class="tab-pane fade" id="panel14" role="tabpanel">
				<br>
				<div class="" id="show-data">
					<?php
						//error_reporting(0);
						/* PARSE JSON FOR META */
						$json_resources_file = file_get_contents('https://www.googleapis.com/storage/v1/b/files.imss.work/o?prefix=brochures/imss_presentation_');
						$jfo_resources = json_decode($json_resources_file);
						$resourcesfiledata = $jfo_resources->items;
						foreach ($resourcesfiledata as $resource_file) {
							$resourcefile_bucket=$resource_file->bucket;
							$resourcefile_name=$resource_file->name;
							$resourcefile_link = 'http://'.$resourcefile_bucket.'/'.$resourcefile_name;
							$resourcefile_metatitle=$resource_file->metadata->metatitle;
							if (substr($resourcefile_link, -1)!='/'){
					?>
							<ul>
								<li>
									<span>
										<?php
											if (isset($resourcefile_metatitle))
												echo $resourcefile_metatitle;
											else
												echo $resourcefile_link;
										?> &nbsp; &nbsp;
									</span>
									<a href="<?php echo $resourcefile_link; ?>" style="font-size:75%;font-weight:bold;">
										Download file
									</a>
								</li>
							</ul>
					<?php
							}
						}
					?>
				</div>
			</div>
			<!--/.Panel 4-->
			<!--Panel 5-->
			<div class="tab-pane fade" id="panel15" role="tabpanel">
				<br>
				<div class="" id="show-data">
					<?php
						//error_reporting(0);
						/* PARSE JSON FOR META */
						$json_resources_file = file_get_contents('https://www.googleapis.com/storage/v1/b/www.myimss.work/o?prefix=apps/library/templates/');
						$jfo_resources = json_decode($json_resources_file);
						$resourcesfiledata = $jfo_resources->items;
						foreach ($resourcesfiledata as $resource_file) {
							$resourcefile_bucket=$resource_file->bucket;
							$resourcefile_name=$resource_file->name;
							$resourcefile_link = 'http://'.$resourcefile_bucket.'/'.$resourcefile_name;
							$resourcefile_metatitle=$resource_file->metadata->metatitle;
							if (substr($resourcefile_link, -1)!='/'){
					?>
							<ul>
								<li>
									<span>
										<?php
											if (isset($resourcefile_metatitle))
												echo $resourcefile_metatitle;
											else
												echo $resourcefile_link;
										?> &nbsp; &nbsp;
									</span>
									<a href="<?php echo $resourcefile_link; ?>" style="font-size:75%;font-weight:bold;">
										Download file
									</a>
								</li>
							</ul>
					<?php
							}
						}
					?>
				</div>
			</div>
			<!--/.Panel 5-->
			<!--Panel 6-->
			<div class="tab-pane fade" id="panel16" role="tabpanel">
				<br>
				<div class="" id="show-data">
					<?php
						//error_reporting(0);
						/* PARSE JSON FOR META */
						$json_resources_file = file_get_contents('https://www.googleapis.com/storage/v1/b/www.myimss.work/o?prefix=apps/library/IMSStalks/');
						$jfo_resources = json_decode($json_resources_file);
						$resourcesfiledata = $jfo_resources->items;
						foreach ($resourcesfiledata as $resource_file) {
							$resourcefile_bucket=$resource_file->bucket;
							$resourcefile_name=$resource_file->name;
							$resourcefile_link = 'http://'.$resourcefile_bucket.'/'.$resourcefile_name;
							$resourcefile_metatitle=$resource_file->metadata->metatitle;
							if (substr($resourcefile_link, -1)!='/'){
					?>
							<ul>
								<li>
									<span>
										<?php
											if (isset($resourcefile_metatitle))
												echo $resourcefile_metatitle;
											else
												echo $resourcefile_link;
										?> &nbsp; &nbsp;
									</span>
									<a href="<?php echo $resourcefile_link; ?>" style="font-size:75%;font-weight:bold;">
										Download file
									</a>
								</li>
							</ul>
					<?php
							}
						}
					?>
				</div>
			</div>
			<!--/.Panel 6-->
			<!--Panel 7-->
			<div class="tab-pane fade" id="pane222" role="tabpanel">
				<br>
				<div class="" id="show-data">
					<?php
						//error_reporting(0);
						/* PARSE JSON FOR META */
						$json_resources_file = file_get_contents('https://www.googleapis.com/storage/v1/b/files.imss.work/o?prefix=brochures/imss-brochure-');
						$jfo_resources = json_decode($json_resources_file);
						$resourcesfiledata = $jfo_resources->items;
						foreach ($resourcesfiledata as $resource_file) {
							$resourcefile_bucket=$resource_file->bucket;
							$resourcefile_name=$resource_file->name;
							$resourcefile_link = 'http://'.$resourcefile_bucket.'/'.$resourcefile_name;
							$resourcefile_metatitle=$resource_file->metadata->metatitle;
							if (substr($resourcefile_link, -1)!='/'){
					?>
							<ul>
								<li>
									<span>
										<?php
											if (isset($resourcefile_metatitle))
												echo $resourcefile_metatitle;
											else
												echo $resourcefile_link;
										?> &nbsp; &nbsp;
									</span>
									<a href="<?php echo $resourcefile_link; ?>" style="font-size:75%;font-weight:bold;">
										Download file
									</a>
								</li>
							</ul>
					<?php
							}
						}
					?>
				</div>
			</div>
			<!--/.Panel 7-->
		</div>
	</main>
    <?php  include '../gglobal/footer-end.php'; ?>
</body>
</html>
