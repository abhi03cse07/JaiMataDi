<?
 mail ("yeshwanth@integramicro.com","Test subject","Test body","From:yeshwanth@integramicro.com");

?>

