	
<?php  include '../gglobal/configurations.php'; ?>

<?php
$URL_APP_BASE = $FEEDBACK_URL_APP_BASE ;
$PRODUCT_ID = $FEEDBACK_PRODUCT_ID ;
$PRODUCT_KEY = $FEEDBACK_PRODUCT_KEY ;
?>

<?php  include '../gglobal/utilities.php'; ?>
<?php  include '../gglobal/validate.php'; ?>

	   

   <?php
       // error_reporting(0);
        /*$current_url1 = explode("?", $_SERVER['REQUEST_URI']);
        $referer_url = explode("=", $current_url1[1]);
        $referer_url=$referer_url[1];
        if (!isset($referer_url)){
            $referer_url="null"; //ENTER USER ID VARIABLE
        }*/
		$app_url = $_GET["app_url"];
		$app_name = $_GET["app_name"];
    ?>
<?php $appname = "Feedback - Issues & feature requests for myimss.work"; ?>
<?php  include '../gglobal/head-top.php'; ?>
<body>
    <?php  include '../gglobal/nav-f.php'; ?>
	<main class="container py-4" style="font-size:125%;">
        Thank You for your feedback. Our team will look into it.<br>
        Go back to
        <?php
            $referer_url=filter_input(INPUT_GET, 'referer_url', FILTER_SANITIZE_URL);;
            if((ISSET($app_url))&&($app_url!="null"))
                echo '<a href="'.$app_url.'">'.ucfirst($app_name).'</a> app.';
            else
                echo '<a href="http://myimss.work">myimss.work</a> home';
        ?>
	</main>
    <?php  include '../gglobal/footer-end.php'; ?>
</body>
</html>
