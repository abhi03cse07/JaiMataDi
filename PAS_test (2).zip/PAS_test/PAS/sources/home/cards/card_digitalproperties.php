<?php include 'cardframe_start.php'; ?>
<h4 class="card-title appnamestyle">
    Digital Properties <br><br></h4>
<a class="dwllink1" href="//imss.work" target="_blank">
    <i class="fab fa-chrome"></i></a> &nbsp;
<a class="dwllink1" href="//facebook.com/IMSSwork" target="_blank">
    <i class="fab fa-facebook"></i>
</a> &nbsp;
<a class="dwllink1" href="//twitter.com/IMSSwork" target="_blank">
    <i class="fab fa-twitter"></i>
</a> &nbsp;
<a class="dwllink1" href="//linkedin.com/company/IMSSwork" target="_blank">
    <i class="fab fa-linkedin"></i>
</a> &nbsp;
<a class="dwllink1" href="//plus.google.com/104236939287432779325" target="_blank">
    <i class="fab fa-google"></i>
</a> &nbsp;
<a class="dwllink1" href="//www.youtube.com/channel/UCRAuEj6cFnTar9jpbR5PIsQ" target="_blank">
    <i class="fab fa-youtube"></i>
</a> &nbsp;
<a class="dwllink1" href="//instagram.com/IMSSwork" target="_blank">
    <i class="fab fa-instagram"></i>
</a>
<?php include 'cardframe_end.php'; ?>
