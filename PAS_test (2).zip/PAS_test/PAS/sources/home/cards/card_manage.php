<?php include 'cardframe_start.php'; ?>
<h5 class="card-title appnamestyle">
<i class="<?php echo $iconcolor; ?> fa fa-cogs iconsize pb-1"></i> <br><br>Manage</h5>
<p class="card-text appdescstyle">Employee selfcare for leaves & bills</p>
<a class="dwllink" href="//apps.myimss.work/manage" target="_blank">
<i class="fas fa-external-link-alt"></i>&nbsp;Open</a>&nbsp;</a>
<a class="dwllink" href="//play.google.com/store/apps/details?id=com.integra.ilts" target="_blank">
<i class="fab fa-android"></i>&nbsp;Android App</a>&nbsp;</a>
<?php include 'cardframe_end.php'; ?>
