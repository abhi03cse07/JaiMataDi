
<?php  include '../gglobal/configurations.php'; ?>

<?php
$URL_APP_BASE = $SCOOP_URL_APP_BASE ;
$PRODUCT_ID = $SCOOP_PRODUCT_ID ;
$PRODUCT_KEY = $SCOOP_PRODUCT_KEY ;
?>

<?php  include '../gglobal/utilities.php'; ?>
<?php  include '../gglobal/validate.php'; ?>


<?php
        error_reporting(0);
        //$current_url1 = explode("?", $_SERVER['REQUEST_URI']);
        //$version = explode("=", $current_url1[1]);
        //$version=$version[1];
		$version=$_GET["version"];
        if (!isset($version)){
            $dateversion="20".date("y").date("m").date("d");
            $version=date("y").date("m");
        }
        else
        {
            if(strlen($version)==7){
                $version=substr(substr($version, 2), 0, -3).substr(substr($version, 2), 3);
                $dateversion="20".$version.date("d");
            }
            else
                $dateversion="20".$version.date("d");
        }
        $JSONversion=date("Y-m-d",strtotime("$dateversion"));
        $url_scoop_make_employee_details="http://172.16.2.10:5100/scoop/getMonthlyScoopList/".$JSONversion;
        $url_scoop_make_updates="includes/archives/scoop-archive-".$version.".php";
    ?>
<?php $appname = "Scoop - ".date("M Y", strtotime($JSONversion))." "." Newsletter"; ?>
<?php  include '../gglobal/head-top.php'; ?>
    <?php  include '../gglobal/nav-f.php'; ?>
    <main class="container">
        <?php
            include $url_scoop_make_updates;
            $module_heading="Birthdays";
            include 'includes/modules/card-deck.php';
            $module_heading="New Joinees";
            include 'includes/modules/card-deck.php';
        ?>
        <br>
    </main>
    <?php $module_heading="View Past Editions";
    include 'includes/modules/module-heading.php';?>
    <p class="text-center">Select Month and Year below</p>
    <form class="text-center">
        <input class="mb-4 p-2 datepicker" style="border:1px solid #cdcdcd;box-shadow: outset 0 3px 6px rgba(0,0,0,0.1);" type="month" name="version" min="2018-08" max="<?php echo date("Y-m"); ?>" value="<?php echo substr(substr($dateversion, 0, -2), 0, -2)."-".substr(substr($dateversion, 0, -2), 4); ?>"/>
        <input class="btn btn-md black-text" type="submit"/>
    </form>
<?php  include '../gglobal/footer-end.php'; ?>
