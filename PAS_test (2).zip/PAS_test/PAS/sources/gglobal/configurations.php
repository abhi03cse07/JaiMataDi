<?php
$URL_IAUTH_BASE="http://localhost:8089/iauth";

$LIBRARY_URL_APP_BASE = "http://localhost/repo/php-portals/sources/library/" ;
$LIBRARY_PRODUCT_ID = "6" ;
$LIBRARY_PRODUCT_KEY = "784541e45c670c30b79098b8ba5c9843";

$SCOOP_URL_APP_BASE = "http://localhost/repo/php-portals/sources/scoop/" ;
$SCOOP_PRODUCT_ID = "7" ;
$SCOOP_PRODUCT_KEY = "f1edd02b3a8c968bf47db6eedf90f885";

$FEEDBACK_URL_APP_BASE = "http://localhost/repo/php-portals/sources/scoop/" ;
$FEEDBACK_PRODUCT_ID = "15" ;
$FEEDBACK_PRODUCT_KEY = "37d3ca5e53a9d43fc4429295fd3719ea";


$URL_VALIDATE_SESSION = $URL_IAUTH_BASE."/rs/iauth/validate/session";
$URL_PRODUCT_LIST = $URL_IAUTH_BASE."/rs/iauth/product/list";
$URL_LOGIN_REDIRECT = $URL_IAUTH_BASE."/access/login";
$URL_LOGOUT_SESSION = $URL_IAUTH_BASE."/rs/iauth/access/logout";

?>