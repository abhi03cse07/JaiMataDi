<?php include 'cardframe_start.php'; ?>
<h5 class="card-title appnamestyle">
<i class="<?php echo $iconcolor; ?> fa fa-wrench iconsize pb-1"></i> <br><br>IT Support</h5>
<p class="card-text appdescstyle">Help for hardware, software & network</p>
<a class="dwllink" href="//apps.myimss.work/itsupport" target="_blank">
<i class="fa fa-medkit"></i>&nbsp;Tickets</a>&nbsp;</a>
<?php include 'cardframe_end.php'; ?>
