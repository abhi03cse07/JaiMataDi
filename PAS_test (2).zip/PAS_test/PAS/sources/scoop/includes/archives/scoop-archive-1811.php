<?php
    $slide1_img="http://www.myimss.work/apps/scoop/archives/img_myimss.work_apps_scoop_carousel_".$version."_slide_1.jpg";
    $slide2_img="http://www.myimss.work/apps/scoop/archives/img_myimss.work_apps_scoop_carousel_".$version."_slide_2.jpg";
    $slide3_img="http://www.myimss.work/apps/scoop/archives/img_myimss.work_apps_scoop_carousel_".$version."_slide_3.jpg";
    $slide1_h3="IMSS opens its newest office in Dubai";
    $slide1_p="Our investments in Dubai reached fruition with the launch of our middle east operations.";
    $slide2_h3="Wishing all IMSS'ians a very happy Diwali";
    $slide2_p="May you have a heart full of joy and a sky full of lights";
    $slide3_h3="International Mens Day";
    $slide3_p="Wishing all the inspiring men in your life a peaceful Movember and a happy mens day ";
    //$slide1_bg="rgba-black-light";
    //$slide2_bg="rgba-black-slight";
    //$slide2_bg="rgba-black-dark";
    $slide1_bg="rgba-black-slight";
    $slide2_bg="rgba-black-slight";
    $slide3_bg="rgba-black-slight";
    include 'includes/modules/carousel-tunein.php';
    $module_heading="Updates and Announcements";
    include 'includes/modules/module-heading.php';
?>
<div class="row">
<div class="card-columns">


    <!--Panel-->
    <div class="card p-3 text-right">
        <blockquote class="blockquote mb-0">
            <p>Notable days in November</p>
            <footer class="blockquote-footer">
                <small class="text-muted">
                <cite title="Source Title">Nov 07</cite> Diwali <br>
                <cite title="Source Title">Nov 14</cite> Children's Day - India <br>
                <cite title="Source Title">Nov 10</cite> World Science Day for Peace & Development <br>
                <cite title="Source Title">Nov 19</cite> International Mens Day <br>
                </small>
            </footer>
        </blockquote>
    </div>
    <!--/.Panel-->


    <!--Panel-->
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Ethnic Day at Integra Group</h5>
            <p class="card-text">Ethnic day is back at Integra. This is the day when all our colleagues are given an opportunity to celebrate the vibrant and colorful festive season. Request all to turn out in costumes of your traditions to look wow and feel great. You have to upload your best dressed up photo at the below link on 6th Oct, 2018 before 2.30 pm. <a href="https://photos.app.goo.gl/eVacG8ZRZVvesrNE8" target="_blank">https://photos.app.goo.gl/eVacG8ZRZVvesrNE8</a></p>
            <img src="http://www.myimss.work/apps/scoop/archives/img_myimss.work_apps_scoop_cascade_1810_img_1.jpg" style="max-width:95%;">
        </div>
    </div>
    <!--/.Panel-->

    <!--Panel-->
    <div class="card">
        <div class="card-body">
            <iframe id="ytplayer" src="https://youtube.com/embed/-20jADK6HgA?autoplay=1&controls=0&showinfo=0&disablekb=1&fs=0&iv_load_policy=3&loop=1&modestbranding=1&rel=0&mute=1&start=0&wmode=transparent" width="100%" height="100%" frameborder="0" style="width:100%;"></iframe><br>
            <h5 class="card-title">IMSS is now in Middle East</h5>
            <p class="card-text"> IMSS continues to expand its network with our new office in DAFZA, Dubai in October 2018. The new office will provide full suite of IMSS services including RPA, Blockchain, Data Analytics and TaaS. </p>
        </div>
    </div>
    <!--/.Panel-->



    <!--Panel-->
    <div class="card text-center">
        <div class="card-body">
            <h5 class="card-title">Spot Award Winners - Oct' 2018</h5>
            <p class="card-text">Congratulating the below IMSS'ians who won awards during October 2018.</p>
            <p class="card-text"><small class="text-muted">
                Indra Kumar S (EBU)<br>
                Sumgna Satish (VMS BU)<br>
                Chetan A Gosavi (VMS BU)<br>
                Prem Kumar Reddy (VMS BU)<br>
                Deepashree K S (VMS BU)<br>
                Kumar Inbanathan (IR BU)<br>
                Monica K (IR BU)<br>
            </small></p>
            <img src="http://www.myimss.work/apps/scoop/archives/img_myimss.work_apps_scoop_cascade_1810_img_3.jpg" style="max-width:95%;">
        </div>
    </div>
    <!--/.Panel-->


    <!--Panel-->
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">IMSS at GITEX 2018, Dubai</h5>
            <p class="card-text">IMSS participated in #GITEX2018 to talk about the the survival of the enterprise amid digital disruption and how enterprises can rethink execution, business processes and information systems with #RPA, #Blockchain and #DataAnalytics solutions from #IMSSwork .</p>
            <iframe id="ytplayer" src="https://youtube.com/embed/j0Ix6M4KewE?autoplay=1&controls=0&showinfo=0&disablekb=1&fs=0&iv_load_policy=3&loop=1&modestbranding=1&rel=0&mute=1&start=0&wmode=transparent" width="100%" height="100%" frameborder="0" style="width:100%;"></iframe>
        </div>
    </div>
    <!--/.Panel-->


    <!--Panel-->
    <div class="card p-3">
        <blockquote class="blockquote mb-0 card-body">
            <p>The new skills app has been successfully piloted at the recruitment drive IMSS conducted in Hyderabad on 3rd Nov. It will soon be part of the myIMSS platform. <a href="http://www.myimss.work" target="_blank">www.myimss.work</a></p>
            <footer class="blockquote-footer" style="text-align:center;">
                <img src="http://www.myimss.work/logos/logo_myim.png" style="max-width:95%;">
            </footer>
        </blockquote>
    </div>
    <!--/.Panel-->

    <!--Panel-->
    <div class="card bg-primary text-white text-center p-3">
        <blockquote class="blockquote mb-0">
            <p>Felicitation for the IMSS team by the hon'ble CM of Karnataka</p>
            <footer class="blockquote-footer" style="color:#ffffff;">
                Our team was felicitated by the CM on Oct 1 towards launching our service for the “Department of differently abled and senior citizens"
            </footer>
            <img src="http://www.myimss.work/apps/scoop/archives/img_myimss.work_apps_scoop_cascade_1810_img_2.jpg" style="max-width:95%;">
        </blockquote>
    </div>
    <!--/.Panel-->


</div>
</div>
