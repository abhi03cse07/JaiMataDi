<?php
    $slide1_img="http://www.myimss.work/apps/scoop/archives/img_myimss.work_apps_scoop_carousel_".$version."_slide_1.jpg";
    $slide2_img="http://www.myimss.work/apps/scoop/archives/img_myimss.work_apps_scoop_carousel_".$version."_slide_2.jpg";
    $slide3_img="http://www.myimss.work/apps/scoop/archives/img_myimss.work_apps_scoop_carousel_".$version."_slide_3.jpg";
    $slide1_h3="Welcoming 2019 and Wish you all a happy Makara Sankranthi";
    $slide1_p="Happy New Year to all the IMSS'ians. May the blesings of nature bring you immense happiness, joy and prosperity.";
    $slide2_h3="Welcome to Q4";
    $slide2_p="Wishing you the very best for the last quarter of this FY";
    $slide3_h3="Launching new and improved i'Manage";
    $slide3_p="As part of IMSS digital transformation initiative we are glad to announce the all new and improved i’Manage - a focused and dedicated app for employee selfcare.";
    //$slide1_bg="rgba-black-light";
    //$slide2_bg="rgba-black-slight";
    $slide1_bg="rgba-black-slight";
    $slide2_bg="rgba-black-light";
    $slide3_bg="rgba-black-slight";
    include 'includes/modules/carousel-tunein.php';
    $module_heading="Updates and Announcements";
    include 'includes/modules/module-heading.php';
?>
<div class="row">
<div class="card-columns">

    <!--Panel-->
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Happy New Year</h5>
            <img src="http://www.myimss.work/apps/scoop/archives/img_myimss.work_apps_scoop_cascade_1901_newyear.jpg" style="max-width:100%;">
        </div>
    </div>
    <!--/.Panel-->

    <!--Panel-->
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Republic Day Wishes</h5>
            <img src="http://www.myimss.work/apps/scoop/archives/img_myimss.work_apps_scoop_cascade_1901_republicday.jpg" style="max-width:100%;">
        </div>
    </div>
    <!--/.Panel-->

    <!--Panel-->
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Happy Makara Sankranthi</h5>
            <p class="card-text">We wish you soar high just like the kites on Makar Sankranthi.</p>
            <p class="card-text"><small class="text-muted">-- Also, remembering the origins of this festival by paying tribute to our agriculturists and farmers who toil in winter's chill, summer's heat or monsoon's rains.</small></p>
            <img src="http://www.myimss.work/apps/scoop/archives/img_myimss.work_apps_scoop_cascade_1901_pongal.jpg" style="max-width:100%;">
        </div>
    </div>
    <!--/.Panel-->

    <!--Panel-->
    <div class="card bg-primary text-white text-left p-3">
        <blockquote class="blockquote mb-0">
            <p>As part of IMSS digital transformation initiative we are glad to announce the all new and improved i’Manage - a focused and dedicated app for employee selfcare. So, give it a try and let us know your feedback by writing to <a href="mailto:myim@imss.work" style="color:yellow;">myim@imss.work</a>.<br><br>You can get the app for Web or Android at <a href="http://myimss.work" style="font-weight:bold;color:yellow;">www.myimss.work</a>. We hope this will make all our lives easier, so that we can free up and focus on things that matter.</p>
            <footer class="blockquote-footer">
                <small style="color:#ffffff;">
                the myIMSS <cite title="Source Title"> team</cite>
                </small>
            </footer>
        </blockquote>
        <br>
        <img src="http://www.myimss.work/apps/scoop/archives/img_myimss.work_apps_scoop_cascade_1901_imanage.jpg" style="max-width:100%;">
    </div>
    <!--/.Panel-->

    <!--Panel-->
    <div class="card text-left">
        <div class="card-body">
            <h5 class="card-title">Inplant training for Students</h5>
            <p class="card-text">Students from L.V. Govt. Polytechnic, Hassan successfully completed in-plant training with IMSS to gain periodical working exposure in organizational environment.</p>
        </div>
    </div>
    <!--/.Panel-->

    <!--Panel-->
    <div class="card" style="background-color:#ffeb00;">
        <div class="card-body">
            <h5 class="card-title">Moving to myimss.work</span></h5>
            <img src="http://www.myimss.work/logos/logo_myim.png" style="max-width:30%;"><br><br>
            <p class="card-text" style="color:#000;">Also, coming soon with myIMSS platform - A unified home for all our enterprise apps with SSO (Single Sign On), streamlined navigation and more. i'Manage, IT Support, Library and Scoop newsletter are the first apps to make the move. In the near future, you will find them all at the same place. Visit <a href="http://myimss.work" style="font-weight:bold;">www.myimss.work</a> to preview the future home of internal apps. </p>
        </div>
    </div>
    <!--/.Panel-->

    <!--Panel-->
    <div class="card p-3">
        <blockquote class="blockquote mb-0 card-body">
            <p>Welcoming Rohit Srigyan as Branch Manager, IMSS - Dubai and Kishan Karkal as Senior Consultant to take care of IMSS - NCR.</p>
            <footer class="blockquote-footer">
                <small class="text-muted">
                Wishing them both continued success in their new avatars.<cite title="Source Title">and all the success in achieving the set organizational goals.</cite>
                </small>
            </footer>
        </blockquote>
    </div>
    <!--/.Panel-->

    <!--Panel-->
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Holiday List 2019</h5>
            <img src="http://www.myimss.work/apps/scoop/archives/img_myimss.work_apps_scoop_cascade_1901_holidaylist.jpg" style="max-width:100%;">
        </div>
    </div>
    <!--/.Panel-->

</div>
</div>
