<?php include 'cardframe_start.php'; ?>
<h5 class="card-title appnamestyle">
<i class="<?php echo $iconcolor; ?> fa fa-folder-open iconsize pb-1"></i> <br><br>Library</h5>
<p class="card-text appdescstyle">Resources, collaterals & files with CDN</p>
<a class="dwllink" href="//apps.myimss.work/library" target="_blank">
<i class="fas fa-external-link-alt"></i>&nbsp;Go to Library</a>&nbsp;</a>
<?php include 'cardframe_end.php'; ?>
