<?php
    $slide1_img="http://www.myimss.work/apps/scoop/archives/img_myimss.work_apps_scoop_carousel_".$version."_slide_1.jpg";
    $slide2_img="http://www.myimss.work/apps/scoop/archives/img_myimss.work_apps_scoop_carousel_".$version."_slide_2.jpg";
    $slide3_img="http://www.myimss.work/apps/scoop/archives/img_myimss.work_apps_scoop_carousel_".$version."_slide_3.jpg";
    $slide1_h3="Scoop's First Birthday";
    $slide1_p="Our monthly scoop newsletter celebrates 1st birthday";
    $slide2_h3="Welcome to Q2";
    $slide2_p="Wishing you the very best for Q2 of this FY";
    $slide3_h3="Congratulations Due for Q1 Targets";
    $slide3_p="Congratulations to domestic sales team for exceeding the order target by 39% and Telecom BU for achieving revenue target";
    //$slide1_bg="rgba-black-light";
    //$slide2_bg="rgba-black-slight";
    $slide1_bg="rgba-black-strong";
    $slide2_bg="rgba-black-strong";
    $slide3_bg="rgba-black-strong";
    include 'includes/modules/carousel-tunein.php';
    $module_heading="Updates and Announcements";
    include 'includes/modules/module-heading.php';
?>
<div class="row">
<div class="card-columns">

    <!--Panel-->
    <div class="card bg-primary text-white text-center p-3">
        <blockquote class="blockquote mb-0">
            <p>SCOOP newsletter celebrates 1 year anniversary. Thank you all for your support and encouragement. Looking forward for more exciting times ahead.</p>
            <footer class="blockquote-footer">
                <small style="color:#ffffff;">
                the Scoop <cite title="Source Title"> team</cite>
                </small>
            </footer>
        </blockquote>
    </div>
    <!--/.Panel-->

    <!--Panel-->
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">HDFC Bank option for Salary Accounts</h5>
            <p class="card-text">To facilitate employees with their banks of choices, IMSS partnered with HDFC bank to open and manage salary accounts.</p>
        </div>
    </div>
    <!--/.Panel-->

    <!--Panel-->
    <div class="card" style="background-color:#ffeb00;">
        <div class="card-body">
            <h5 class="card-title">Moving to myimss.work</span></h5>
            <img src="http://www.myimss.work/logos/logo_myim.png" style="max-width:30%;"><br><br>
            <p class="card-text" style="color:#000;">To create a unified and simplified experience, we streamlined the branding of various internal apps to a single umbrella brand. IT Support, Library and Scoop newsletter are the first apps to make the move. In the near future, you will find them all at the same place. Visit <a href="http://myimss.work" style="font-weight:bold;">myimss.work</a> to preview the future home of internal apps.</p>
            <!--p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p-->
        </div>
    </div>
    <!--/.Panel-->

    <!--Panel-->
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">IMSS Partners with UI Path for RPA</h5>
            <img src="http://files.imss.work/logos/logo_imss_612x317.png" style="max-width:35%;"> &nbsp; &nbsp; &nbsp;
            <img src="http://files.imss.work/logos/partners/logo_partner_uipath.png" style="max-width:45%;"><br><br>
            <p class="card-text">IMSS is now a boutique partner for UI Path. UI Path is the world's leading RPA vendor providing a complete platform to efficiently automate business processes. </p>
            <p class="card-text"><small class="text-muted">-- as per Forrester Wave 2018. In picture - Animesh Bisaria and Seema Nair with the founder of UI Path - Daniel Dines</small></p>
            <img src="http://www.myimss.work/apps/scoop/archives/img_myimss.work_apps_scoop_cascade_1808_img_1.jpg" style="max-width:95%;">
        </div>
    </div>
    <!--/.Panel-->

    <!--Panel-->
    <div class="card p-3">
        <blockquote class="blockquote mb-0 card-body">
            <p>IMSS is now working with the Directorate of Electronic Delivery of Citizen Services (EDCS) on its eGovernance initiatives.</p>
            <footer class="blockquote-footer">
                <small class="text-muted">
                Our teams are currently deployed at EDCS on these projects. <cite title="Source Title">We look forward to contribute more towards making governance better with technology.</cite>
                </small>
            </footer>
        </blockquote>
    </div>
    <!--/.Panel-->

    <!--Panel-->
    <div class="card text-center">
        <div class="card-body">
            <h5 class="card-title">Magazine Features</h5>
            <p class="card-text">We are featured in CEO magazine - Best Global Brands to Watch in 2018. We were also featured in recognized by CIO review as one of the 20 most promising software testing solution provider in 2018.</p>
            <p class="card-text"><small class="text-muted">CEO Magazine and CIO Review are leading business magazines that cover enterprise technology, IT professionals and entrepreneurs.</small></p>
        </div>
    </div>
    <!--/.Panel-->

    <!--Panel-->
    <div class="card p-3 text-right">
        <blockquote class="blockquote mb-0">
            <p>We are switching to an automated webapp version of the Scoop newsletter. To get the latest edition, just visit <a href="http://app.myimss.work/scoop">app.myimss.work/scoop</a></p>
            <footer class="blockquote-footer">
                <small class="text-muted">
                the Scoop <cite title="Source Title"> team</cite>
                </small>
            </footer>
        </blockquote>
    </div>
    <!--/.Panel-->

</div>
</div>
