<?php include 'cardframe_start.php'; ?>
<h5 class="card-title appnamestyle">
<i class="<?php echo $iconcolor; ?> fa fa-eye iconsize pb-1"></i> <br><br>Scoop</h5>
<p class="card-text appdescstyle">Monthly newsletter with updates & chatter</p>
<a class="dwllink" href="//apps.myimss.work/scoop" target="_blank">
<i class="fab fa-readme"></i>&nbsp;Read now</a>&nbsp;</a>
<?php include 'cardframe_end.php'; ?>
