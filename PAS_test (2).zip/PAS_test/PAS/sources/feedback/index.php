	
<?php  include '../gglobal/configurations.php'; ?>

<?php
$URL_APP_BASE = $FEEDBACK_URL_APP_BASE ;
$PRODUCT_ID = $FEEDBACK_PRODUCT_ID ;
$PRODUCT_KEY = $FEEDBACK_PRODUCT_KEY ;
?>

<?php  include '../gglobal/utilities.php'; ?>
<?php  include '../gglobal/validate.php'; ?>

	
	
	<?php
        error_reporting(0);
        /*$current_url1 = explode("?", $_SERVER['REQUEST_URI']);
        $referer = explode("=", $current_url1[1]);
        $referer=$referer[1];*/
		$referer=$_GET["userName"];
		$product=$_GET["frmPrdId"];
        if (!isset($product)){
            $product="null"; //ENTER USER ID VARIABLE
        }
    ?>
<?php $appname = "Feedback - Issues & feature requests for apps.myimss.work"; ?>
<?php  include '../gglobal/head-top.php'; ?>
    <?php  include '../gglobal/nav-f.php'; ?>
	<style>body{text-align:center !important;}</style>
	<main class="container py-4 text-center mt-4">
		<!-- Default form contact -->
		<form class="card ml-auto mr-auto text-center border border-light p-5" style="max-width:400px;" action="feedback_action.php" method="post">
		<?php
			$productUrl = "";
			$productList = ImssUtilities::getProductList();
					
			if((ISSET($product))&&($product!="null")){
				for ($x = 0; $x < count($productList); $x++) {
					if($productList[$x]->id == $product){ 
						$displayautolabel=$productList[$x]->productName;
						$productUrl=$productList[$x]->url;
						break;
					}
				}
				$displayclass="hide";
			}
			else
				$displayautolabel="Feedback / Ideas";
		?>
		<p class="h6 mb-2">Tell us about your issue in</p>
		<!-- Subject -->
		<!-- <label style="font-weight:bold !important;font-size:150%;"><?php echo $displayautolabel;?></label> -->
		<input type="hidden" id="referer" class="form-control" name="referer" value="<?php echo $referer;?>">
		<input type="hidden" id="app_url" class="form-control" name="app_url" value="<?php echo urlencode($productUrl);?>">
		

		<select name="app_name" id="app_name" class="browser-default custom-select mb-4 ">
		<?php 
			
			for ($x = 0; $x < count($productList); $x++) {
				
				if($productList[$x]->id == $product){
					$selected = "selected";
				} else {
					$selected = "";
				}
				
				echo '<option '.$selected.' value="'.$productList[$x]->productName.'">'.$productList[$x]->productName.'</option>';
			}
		?>
		</select>
		<!--
		<select <?php if($displayclass!=="hide") echo "required";?> name="app_name" id="app_name" class="browser-default custom-select mb-4 <?php echo $displayclass;?>">
			<option value="" disabled selected>Select App</option>
			<option value="Chat" >Hangouts Chat</option>
			<option value="Meet">Hangouts Meet</option>
			<option value="iManage">i'Manage</option>
			<option value="IT Support">IT Support</option>
			<option value="Library">Files & Library</option>
			<option value="Scoop">Scoop Newsletters</option>
			<option value="Enquiry">Sales & Enquiries</option>
			<option value="Skills">Skill Evaluation</option>
			<option value="Talent">Talent Management</option>
			<option value="Performance">Appraisal Forms</option>
		</select>
-->

		<!-- Message -->
		<div class="form-group">
			<textarea name="feedback_description" class="form-control rounded-0" id="feedback_description" rows="5" placeholder="Write about your issue or feature request"></textarea>
		</div>


		<!-- Send button -->
		<input class="btn btn-info btn-block" type="submit" name="send"></input>

		</form>
		<!-- Default form contact -->
	</main>
    <?php  include '../gglobal/footer-end.php'; ?>
</body>
</html>
