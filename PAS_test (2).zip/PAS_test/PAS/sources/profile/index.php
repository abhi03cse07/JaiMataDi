
<?php
    include 'gglobal/configurations.php';
    $URL_APP_BASE = $LIBRARY_URL_APP_BASE ;
    $PRODUCT_ID = $LIBRARY_PRODUCT_ID ;
    $PRODUCT_KEY = $LIBRARY_PRODUCT_KEY ;
    include 'gglobal/utilities.php';
    include 'gglobal/validate.php';

    error_reporting(0);
    $current_url1 = explode("?", $_SERVER['REQUEST_URI']);
    $profile = explode("=", $current_url1[1]);
    $profile=$profile[1];
    if (!isset($profile)){
        $url_profile_make_employee_details="http://172.16.2.13:81/imssServices/employeeServices.php?serviceName=employeeDetails&empId=".$userName;
    }
    else{
        if(is_numeric($profile))
            $url_profile_make_employee_details="http://172.16.2.13:81/imssServices/employeeServices.php?serviceName=employeeDetails&empId=".$profile;
        else
            $url_profile_make_employee_details="http://172.16.2.13:81/imssServices/employeeServices.php?serviceName=employeeDetails&username=".$profile;
    }
    //$url_profile_make_employee_details="http://localhost/workspace/app.myimss.work/profile/sample.json";
    $emp_data=json_decode(file_get_contents($url_profile_make_employee_details))->employeeDetails;
    $emp_data_status=json_decode(file_get_contents($url_profile_make_employee_details))->statusMsg;
    $url_profile_make_all="http://172.16.2.13:81/imssServices/employeeServices.php?serviceName=allEmployeeDetails";
    //$url_profile_make_all="http://localhost/workspace/app.myimss.work/profile/employees.json";
    $emp_list_data=json_decode(file_get_contents($url_profile_make_all))->employeeDetails;
?>

<?php $appname = "Profile - ".$emp_data->empName; ?>
<?php  include 'gglobal/head-top.php'; ?>
    <link rel="stylesheet" href="../gglobal/assets/awesomplete.css"/>
    <script src="../gglobal/assets/awesomplete.min.js"></script>
    <?php  include 'gglobal/nav-f.php'; ?>
	<main class="container py-4">
        <!-- Search form -->
        <div class="md-form active-purple-2 mb-3">
            <style>.awesomplete{width:75%;text-align:left;margin-right:0;padding-right:0;}select {-moz-appearance: none !important;-webkit-appearance: none !important;}select::-ms-expand {display: none;}#fwsearchform .waves-input-wrapper{width:25% !important;}.awesomplete > ul{margin-top:-1rem;}</style>
            <form id="fwsearchform" class="text-center form-inline md-form form-sm active-cyan-2 mt-2" style="width:100% !important">
                <input list="mylist" class="awesomplete mb-4 p-2 form-control form-control-sm mr-3 w-100" type="text" placeholder="Search by Name" data-minchars="1" data-autofirst="1" data-maxitems="10" aria-label="Search People" name="profile" autocomplete="off" />
                <datalist id="mylist">
                    <?php foreach ($emp_list_data as $emp_indiv) {?>
                        <option value="<?php echo strstr($emp_indiv->imssEmail , '@', true) ?>"><?php echo $emp_indiv->empName ?></option>
                    <?php } ?>
                </datalist>
                <input class="btn btn-md black-text" type="submit"/>
            </form>
        </div>
        <!-- Profile -->
        <div class="row content">
            <div class="col-lg-2 col-md-12">
                <img src="<?php echo "http://www.myimss.work/apps/people/profilepic/".$emp_data->empId.".jpg"; ?>" alt="" style="width: 100%;"/>
            </div>
            <div class="col-lg-6 col-md-12 black-text mt-3">
                <p>
                    <?php $emp_name_array=(explode(' ', $emp_data->empName, 2)); ?>
                    <span class="firstname" style="font-size: 250%;line-height:70%;"><?php echo $emp_name_array[0]; ?> </span>
                    <span class="lastname" style="font-size: 150%;line-height:150%;"><?php echo $emp_name_array[1]; ?></span><br>
                    <span class="designation" style="font-size:120%;letter-spacing: -0.5px;line-height:110%;">&nbsp;<?php echo $emp_data->designation; ?></span><br><br>
                    <span class="doj" style="font-size:90%;line-height:120%;"><?php if($profile==$userName) echo "Joined ".date('d',strtotime($emp_data->dateOfJoin))."&nbsp;".date('M',strtotime($emp_data->dateOfJoin))."&nbsp;".date('Y',strtotime($emp_data->dateOfJoin)); ?></span></span><br>
                    <span class="deployed" style="font-size:90%;line-height:120%;">Works from IMSS Jakkur campus.</span><br><br>
                    <span class="dob" style="font-size:90%;line-height:150%;">Birthday: <?php echo date('d',strtotime($emp_data->dateOfBirth))."&nbsp;".date('M',strtotime($emp_data->dateOfBirth)) ?><span class="dobyear"><?php if($profile==$userName) echo "&nbsp;".date('Y',strtotime($emp_data->dateOfBirth)); ?></span><br><span>Blood Group: <?php echo $emp_data->empBloodGroup; ?></span></span>
                </p>
                <button class="btn btn-md blue">Work Profile</button> &nbsp;
                <button class="btn btn-md blue">Your Blogs</button>
                <p class="small mt-4">Contact HR or reporting manager to update any details</p>
            </div>
            <div class="col-lg-4 col-md-12" style="border:#000000 1px solid;padding:2%;text-align: left;font-size: 100%;line-height: 150%;">
                <h4>Contact Details</h4>
                <address>
                    <span><?php echo $emp_data->empAddress; ?><br></span>
                    <a href="mailto:<?php echo $emp_data->imssEmail; ?>"><?php echo $emp_data->imssEmail; ?></a><br>
                    <a href="tel:<?php if($profile==$userName) echo $emp_data->mobile; ?>"><?php if($profile==$userName) echo $emp_data->mobile; ?></a>
                </address>
                <br>
                <h4>Emergency Contact</h4>
                <div>
                    <?php echo $emp_data->empEmergencyContactName; ?>
                    <span style="font-size:90%;color:#979797;"><?php echo $emp_data->empEmergencyContactRelation; ?></span><br>
                    <a href="mailto:<?php echo $emp_data->empEmergencyContactEmail; ?>"><?php echo $emp_data->empEmergencyContactEmail; ?></a><br>
                    <a href="tel:<?php echo $emp_data->empEmergencyContactPhone; ?>"><?php echo $emp_data->empEmergencyContactPhone; ?></a>
                </div>
                <br>
                <h4>Reporting To</h4>
                <div>
                <?php echo $emp_data->reportsToName; ?><br>
                <?php $profile=$emp_data->reportsToId;$url_profile_make_employee_details="http://172.16.2.13:81/imssServices/employeeServices.php?serviceName=employeeDetails&empId=".$profile;
                    $emp_data=json_decode(file_get_contents($url_profile_make_employee_details))->employeeDetails; ?>
                    <a href="mailto:<?php echo $emp_data->imssEmail; ?>"><?php echo $emp_data->imssEmail; ?></a><br>
                    <a href="tel:<?php if($profile==$userName) echo $emp_data->imssMobile; ?>"><?php if($profile==$userName) echo $emp_data->imssMobile; ?></a>
                </div>
            </div><!-- /sidebar -->
        </div><!-- /row content -->
        <br class="clear" style="clear: both;display: block;"/>
	</main>
    <?php  include '../gglobal/footer-end.php'; ?>
