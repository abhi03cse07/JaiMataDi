<?php include 'cardframe_start.php'; ?>
<h4 class="card-title appnamestyle">
<i class="<?php echo $iconcolor; ?> fa fa-university iconsize pb-1"></i> <br><br>Skills</h4>
<p class="card-text appdescstyle">Skill evaluation for hiring & training</p>
<?php include 'cardframe_end.php'; ?>
