<?php include 'cardframe_start.php'; ?>
<h4 class="card-title appnamestyle">
<i class="<?php echo $iconcolor; ?> fa fa-graduation-cap iconsize pb-1"></i> <br><br>Talent</h4>
<p class="card-text appdescstyle">Manage talent for teams & projects</p>
<?php include 'cardframe_end.php'; ?>
