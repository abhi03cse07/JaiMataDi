//head.load("http://www.myimss.work/includes/gtm-head.js");
//head.load("http://www.myimss.work/includes/gtm-body.js");
head.load("../gglobal/ga.js");
