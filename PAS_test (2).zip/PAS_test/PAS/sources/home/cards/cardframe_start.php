<!--Panel-->
    <!-- Card Narrower -->
    <div class="card <?php echo $cardcolor;?> mb-4 card-cascade narrower col-md-12 col-sm-12 col-xs-12">
        <div class="card-body cardstyle">
