<?php include 'cardframe_start.php'; ?>
<h5 class="card-title appnamestyle">
<i class="<?php echo $iconcolor; ?> fa fa-video iconsize pb-1"></i> <br><br>Google Meet</h5>
<p class="card-text appdescstyle">Group video calls & screensharing</p>
<a class="dwllink" href="//gsuite.google.com/learning-center/products/meet/get-started/#!/"
target="_blank">
<i class="fa fa-info-circle"></i>&nbsp;Info</a> &nbsp;
<a class="dwllink" href="//meet.google.com/" target="_blank">
<i class="fa fa-phone"></i>&nbsp;Start Call</a>
<?php include 'cardframe_end.php'; ?>
