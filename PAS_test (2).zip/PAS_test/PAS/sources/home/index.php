<?php $appname = "Apps"; ?>
<?php  include '../gglobal/head-top.php'; ?>
    <?php include '../gglobal/nav-f.php';include 'jumbotron.php';?>
    <style>
        body{text-align: center !important;}
        .card {width: 100%;}
        .cardstyle {text-align: center;font-weight: bold !important;}
        .appnamestyle {font-size: 125%; color:#ffffff !important;}
        .appdescstyle{font-size: 80% !important;font-weight: bold !important;color:#ffffff !important;}
        .dwllink{font-size: 90% !important;color:#ffffff !important;}
        .dwllink1 {font-size: 175% !important;margin: 3%; color:#ffffff !important;}
        .iconsize {font-size: 400%;}
    </style>
    <main class="container py-2">
        <div class="row">
            <div class="card-deck">
                <?php $cardcolor="deep-orange";$iconcolor="white-text";include 'cards/card_manage.php'; ?>
                <?php $cardcolor="green";$iconcolor="white-text";include 'cards/card_itsupport.php';?>
                <?php $cardcolor="blue-grey";$iconcolor="white-text";include 'cards/card_library.php';?>
                <?php $cardcolor="pink";$iconcolor="white-text";include 'cards/card_scoop.php';?>
            </div>
        </div>
        <div class="row">
            <div class="card-deck">
                <?php $cardcolor="cyan lighten-1";$iconcolor="white-text";include 'cards/card_sendy.php';?>
                <?php $cardcolor="blue";$iconcolor="white-text";include 'cards/card_chat.php';?>
                <?php $cardcolor="grey";$iconcolor="white-text";include 'cards/card_meet.php';?>
                <?php $cardcolor="teal";$iconcolor="white-text";include 'cards/card_digitalproperties.php';?>
            </div>
        </div>
        <h1 class="mb-3">Coming Soon</h1>
        <div class="row">
            <div class="card-deck">
                <?php $cardcolor="grey lighten-1";$iconcolor="grey-text"; include 'cards/card_skills.php'; ?>
                <?php $cardcolor="grey lighten-1";$iconcolor="grey-text"; include 'cards/card_crm.php'; ?>
                <?php $cardcolor="grey lighten-1";$iconcolor="grey-text"; include 'cards/card_talent.php'; ?>
                <?php $cardcolor="grey lighten-1";$iconcolor="grey-text"; include 'cards/card_wiki.php'; ?>
            </div>
        </div>
    </main>
<?php  include '../gglobal/footer-end.php'; ?>
