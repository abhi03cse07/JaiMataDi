<?php include 'cardframe_start.php'; ?>
<h4 class="card-title appnamestyle">
<i class="<?php echo $iconcolor; ?> fa fa-briefcase iconsize pb-1"></i> <br><br>CRM</h4>
<p class="card-text appdescstyle">Manage sales & resources funnel</p>
<?php include 'cardframe_end.php'; ?>
