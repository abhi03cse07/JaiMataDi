window.onload = function (){
$(document).ready(function(){
	$("#noticount").val("1");
	getNotification();
});
$("#notiIcon").on('click',function(){
	$("#noticount").val("0");
	getNotification();
	$("#notiCount").html("0");
});
}


function getNotification(){
	
}