<?php include 'cardframe_start.php'; ?>
<h4 class="card-title appnamestyle">
<i class="<?php echo $iconcolor; ?> fa fa-universal-access iconsize pb-1"></i> <br><br>Wiki</h4>
<p class="card-text appdescstyle">Policy & Process manuals</p>
<?php include 'cardframe_end.php'; ?>
