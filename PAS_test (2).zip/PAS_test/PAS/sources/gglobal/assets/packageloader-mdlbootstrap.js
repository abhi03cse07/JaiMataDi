head.load("//use.fontawesome.com/releases/v5.5.0/css/all.css");
head.load("../gglobal/assets/bootstrap.min.css");
head.load("../gglobal/assets/mdb.min.css");
head.load("../gglobal/assets/jquery-3.3.1.min.js");
head.load("../gglobal/assets/popper.min.js");
head.load("../gglobal/assets/bootstrap.min.js");
head.load("../gglobal/assets/mdb.min.js");
head.load("../gglobal/assets/myim.css");
