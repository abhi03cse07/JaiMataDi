<?php include 'cardframe_start.php'; ?>
<h4 class="card-title appnamestyle">
<i class="<?php echo $iconcolor; ?> fa fa-envelope-square iconsize pb-1"></i> <br><br>Sendy</h4>
<p class="card-text appdescstyle">Email Campaign Management</p>
<a class="dwllink" href="http://go.imss.work/sendy" target="_blank">
<i class="fas fa-external-link-alt"></i> &nbsp; Open App</a>&nbsp;</a>
<?php include 'cardframe_end.php'; ?>
