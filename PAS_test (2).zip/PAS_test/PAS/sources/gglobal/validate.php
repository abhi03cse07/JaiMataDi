

<?php

session_start();

if(isset($_GET['action'])){
	$action = $_GET['action'];
} else {	
	//By default set the action to view
	$action = "view";
}
	
if(isset($_GET['securityToken']) && isset($_GET['userName'])) {
	//This means that it is entering the page for the first time via the dashboard / menu
	$securityToken = $_GET['securityToken'];
	$userName = $_GET['userName'];
	$isFirstEntry = true;
} else if(isset($_SESSION['userDetails']) && isset($_SESSION['productList'])) {
	//This means that a valid session is available
	$securityToken = ImssUtilities::getSecurityToken();
	$userName =  ImssUtilities::getUserName();
	$isFirstEntry = false;
} else {
	
	//Means session is invalid and it needs to be redirected to the login page
	
	// remove all session variables
	session_unset();

	// destroy the session
	session_destroy(); 
	
	//Redirect to iauth login page
	header('Location: '.ImssUtilities::getLoginRedirectURL($URL_LOGIN_REDIRECT, $URL_APP_BASE, $PRODUCT_ID, $PRODUCT_KEY, 'Invalid session, please login again to access the portal.', '0') );
    exit();
}


if($action == 'logout'){
	
	$data = array("productId" => $PRODUCT_ID,"productKey" => $PRODUCT_KEY,"userName" => $userName, "securityToken" => $securityToken, "menuKey" => "LOG", "menuAction" => "V");

	if($isFirstEntry === true){
		//Retrieve use details only for the first time entry
		$data["retrieveUserDetails"] = '1';
	}

	$response = json_decode(ImssUtilities::CallAPI("POST",$URL_LOGOUT_SESSION,json_encode($data)));
	if($response->resultStatus == 'success'){
		// remove all session variables
		session_unset();

		// destroy the session
		session_destroy(); 
		
		//Redirect to iauth login page
		header('Location: '.ImssUtilities::getLoginRedirectURL($URL_LOGIN_REDIRECT, $URL_APP_BASE, $PRODUCT_ID, $PRODUCT_KEY, 'Successfully logged out of the application.', '1') );
		exit();
	} else {
		header('Location: '.ImssUtilities::getLoginRedirectURL($URL_LOGIN_REDIRECT, $URL_APP_BASE, $PRODUCT_ID, $PRODUCT_KEY, 'Unable to logout ('.$response->message.')' , '0') );
		exit();
	}
} else if($action == 'view'){
	
	$data = array("productId" => $PRODUCT_ID,"productKey" => $PRODUCT_KEY,"userName" => $userName, "securityToken" => $securityToken, "menuKey" => "LOG", "menuAction" => "V", "retrieveUserDetails" => "0");

	if($isFirstEntry === true){
		//Retrieve use details only for the first time entry
		$data["retrieveUserDetails"] = '1';
	}

	$response = json_decode(ImssUtilities::CallAPI("POST",$URL_VALIDATE_SESSION,json_encode($data)));

	if($response->resultStatus == 'success'){
		
		if($isFirstEntry === true) {
			$prd_data = array("productId" => $PRODUCT_ID,"productKey" => $PRODUCT_KEY,"userName" => $userName, "securityToken" => $securityToken);
			$prd_response = json_decode(ImssUtilities::CallAPI("POST",$URL_PRODUCT_LIST,json_encode($data)));
			if($prd_response->resultStatus == 'success'){
				
				//Setting the data into the session object
				$_SESSION['userDetails'] = $response;
				$_SESSION['productList'] = $prd_response->listOfElements;
						
				
			} else {
				header('Location: '.ImssUtilities::getLoginRedirectURL($URL_LOGIN_REDIRECT, $URL_APP_BASE, $PRODUCT_ID, $PRODUCT_KEY, $response->message.' (Unable to retrieve product list)' , '0') );
				exit();
			}
		} 
			
	} else {
		header('Location: '.ImssUtilities::getLoginRedirectURL($URL_LOGIN_REDIRECT, $URL_APP_BASE, $PRODUCT_ID, $PRODUCT_KEY, $response->message , '0') );
		exit();
	}

}

?>
