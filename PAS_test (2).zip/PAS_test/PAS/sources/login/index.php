<?php $appname = "PASS APP NAME FROM YOUR APP"; ?>
<?php  include '../gglobal/head-top.php'; ?>
    <style>body{text-align:center !important;}</style>
    <img class="mt-5" src="http://www.myimss.work/logos/logo_myim.png" width="120px;" style="padding-left:10px;">
    <main class="text-center mt-4">
            <div class="card text-center ml-auto mr-auto" style="display:block;width: 22rem;">
                <div class="card-header grey white-text" style="font-size:150%;">Login</div>
                <div class="card-body">
                    <form>
                        <label for="defaultFormCardNameEx" class="grey-text">Username</label>
                        <input type="text" id="defaultFormCardNameEx" class="form-control">
                        <br>
                        <label for="defaultFormCardEmailEx" class="grey-text">Password</label>
                        <input type="password" id="defaultFormCardEmailEx" class="form-control">
                        <div class="text-center py-4 mt-3">
                            <button class="btn btn-grey btn-md" type="submit">Login<i class="fas fa-sign-in-alt ml-2"></i></button>
                        </div>
                        <p class="card-text small">If you forgot your credentials, contact HR or admin.</p>
                    </form>
                </div>
                <div class="card-footer text-muted grey white-text">
                    <p class="mb-0"><?php echo $appname; ?></p>
                </div>
            </div>
	</main>
</body>
</html>
