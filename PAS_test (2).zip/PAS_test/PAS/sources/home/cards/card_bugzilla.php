<?php include 'cardframe_start.php'; ?>
<h4 class="card-title appnamestyle">
<i class="<?php echo $iconcolor; ?> fa fa-bug iconsize pb-1"></i> <br><br>Bugzilla</h4>
<p class="card-text appdescstyle">Bug tracking & management</p>
<a class="dwllink" href="//apps.myimss.work/bugzilla" target="_blank">
<i class="fas fa-external-link-alt"></i> &nbsp; Open App</a>&nbsp;</a>
<?php include 'cardframe_end.php'; ?>
