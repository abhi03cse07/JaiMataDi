<?php $base_href="http://".($_SERVER['HTTP_HOST'])."/"; ?>
<!DOCTYPE html><html lang="en">
<?php error_reporting(0); ?>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php echo "myIM ".$appname; ?></title>
    <script type="text/javascript" src="../gglobal/assets/head.min.js"></script>
    <script type="text/javascript" src="../gglobal/assets/packageloader-mdlbootstrap.js"></script>
    <script type="text/javascript" src="../gglobal/assets/ga.js"></script>
</head>
<body class="" style="font-family: 'Quicksand', sans-serif;">
