<?php include 'cardframe_start.php'; ?>
<h5 class="card-title appnamestyle">
<i class="<?php echo $iconcolor; ?> fa fa-comments iconsize pb-1"></i> <br><br>Google Chat</h5>
<p class="card-text appdescstyle">Secure team chat & chatBOTs for IMSS</p>
<a class="dwllink" href="//get.google.com/chat/" target="_blank">
<i class="fa fa-download"></i>&nbsp;Apps</a> &nbsp;
<a class="dwllink" href="//chat.google.com/" target="_blank">
<i class="fas fa-comment"></i>&nbsp;Start Chat</a>
<?php include 'cardframe_end.php'; ?>
