
    <footer class="page-footer font-small mdb-color lighten-3 pt-4 mt-4">
        <div class="footer-copyright text-center py-3">
        <a href="//myimss.work">Powered by myIM Platform.</a><br>2019 © Integra Micro Software Services
        </div>
    </footer>
    <link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
</body>
</html>
