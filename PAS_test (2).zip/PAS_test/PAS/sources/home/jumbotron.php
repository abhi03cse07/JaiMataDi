<br>
    <div class="container">
        <div class="row">

            <!--Grid column-->
            <div class="col-lg-12 col-md-12">
                <!-- Jumbotron -->
                    <!-- Descirption -->
                    <h1 class="h2-responsive mb-1"><strong>Welcome to the new home of Digital IMSS</strong></h1>
                </div>
                <!-- Jumbotron -->
            </div>
            <!--Grid column-->
        </div>
    </div>
        <style type="text/css">@keyframes blinker {50% {background-color: turquoise;}}</style>
<p class="mdl-chip" onclick="window.open('https://goo.gl/forms/KzG9toRYBRYIIhRn2')" style="cursor:pointer;background-color:#ffffff;font-size:100%;animation: blinker 1s linear infinite;"><span class="mdl-chip__text" style="font-size:110%;"> &nbsp; &nbsp; Enter your Jacket Size here &nbsp; <a href="https://goo.gl/forms/KzG9toRYBRYIIhRn2" target="_blank">https://goo.gl/forms/KzG9toRYBRYIIhRn2</a></span></p>
<br>
