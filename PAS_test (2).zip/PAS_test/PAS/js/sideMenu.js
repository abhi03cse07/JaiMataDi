function openLink(link,menuVal){
	
	$('#menu').val(menuVal);
	$('#mainMenu').attr("action", link);
	$('#mainMenu').submit();
}

$(document).ready(function(){
	//This below code is to mark the current menu as highlighted
	currentMenuParentId = $('[current-menu="true"]').attr("parent-id"); //get the current menu's parent id
	$('[self-id="'+currentMenuParentId+'"]').addClass("active").addClass("open"); //add the class active and open to the parent node
	
});
