	
<?php  include '../gglobal/configurations.php'; ?>

<?php
$URL_APP_BASE = $FEEDBACK_URL_APP_BASE ;
$PRODUCT_ID = $FEEDBACK_PRODUCT_ID ;
$PRODUCT_KEY = $FEEDBACK_PRODUCT_KEY ;
?>

<?php  include '../gglobal/utilities.php'; ?>
<?php  include '../gglobal/validate.php'; ?>

	

<?php
    error_reporting(0);
    $referer= $_POST["referer"];
    $app_name=$_POST["app_name"];
    $app_url=$_POST["app_url"];
    $feedback_description=$_POST["feedback_description"];
    $email_to="myim@imss.work";
	$email_from="myim@imss.work";
    $email_subject="[myIMSS][".$app_name."][Feedback]";
    $email_body="New feedback has been submitted"."<br>"."Refered By: ".$referer."<br>"."Feedback about: ".$app_name."<br>"."<br>"."Feedback:"."<br>".$feedback_description;
    mail($email_to,$email_subject,$email_body);
	
	date_default_timezone_set("Asia/Kolkata");
	$log  = 'Date:'.date("d-m-Y H:i:s").PHP_EOL."Refered By: ".$referer.PHP_EOL."Feedback about: ".$app_name.PHP_EOL."Feedback:".$feedback_description.PHP_EOL."******************************************************************".PHP_EOL;
	//Save string to log, use FILE_APPEND to append.
	file_put_contents('./feedback.log', $log, FILE_APPEND);
	
    $reditect_to="thank.php?app_name=".$app_name."&app_url=".$app_url;
    header("HTTP/1.1 301 Moved Permanently");
	header("Location: ".$reditect_to);
	exit();
?>
