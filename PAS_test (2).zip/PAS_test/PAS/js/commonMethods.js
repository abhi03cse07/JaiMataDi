var flag = true;
$(document).ready(function(){	
	jQuery.validator.setDefaults({
	  debug: false,
	  onkeyup: function(element) {$(element).valid()},
	  errorPlacement: function(error,element) {
		
			//This is to remove the default placement of error messages, instead it is replaced by the custom message
			return true;
		}, 
		invalidHandler: function(event, validator) {
							handleCustomMessageDisplay(event, validator);
				}
	});	
	
	jQuery.validator.addMethod("comboMandatory", function(value, element) {
	    return this.optional(element) || (parseFloat(value) > 0);
	}, "Please select a value");
	
	
	/***************************************************************
	 * This below code is for truncating the text in the divs with the 
	 * class int-truncate-text to the length specified and add a qtip 
	 * with the original text
	 **************************************************************/
	var maxDefault = 200;
	var tot, str, orgStr;
	var max;
	$('.int-truncate-text').each(function() {
		
		if($(this).attr("int-max-length")){
			max = eval($(this).attr("int-max-length"));
		} else {
			max = maxDefault;
		}
		
		orgStr = String($(this).html());
		tot = orgStr.length;
		str = (tot <= max)
				? orgStr
				: orgStr.substring(0,(max + 1))+"...";
		$(this).html(str);

		$(this).qtip({
			suppress: false,
			content: {
				text:orgStr
			},
			position: {
				my: 'top center',
				at: 'bottom, center'
			},
			show: {
				event: 'mouseover'
			},
			style: {
				classes: 'qtip-blue qtip-rounded'
			}
		});	
	});
	/***************************************************************
	 * End of code for truncate
	 ***************************************************************/
	
	
	loadQTipForAllControls();
	
	//networkCheck();
});


function loadQTipForAllControls(){
	$('[qtip-text]').each(function(){

		var orgStr = $(this).attr('qtip-text');
		
		$(this).qtip({
			suppress: false,
			content: {
				text:orgStr
			},
			position: {
				my: 'bottom center',
				at: 'top, center'
			},
			show: {
				event: 'mouseover'
			},
			style: {
				classes: 'qtip-blue qtip-rounded'
			}
		});
	});
}

function handleCustomMessageDisplay(event, validator){
	console.log(validator);
	
	//Remove all the qtips
	for(var i = 0 ; i < validator.currentElements.length; i++){
		$(validator.currentElements[i]).parents(".form-group:first").removeClass("has-error");
	
		//This is to handle UI for error for the select2 related divs
		$(validator.currentElements[i]).parents(".form-group:first").children(".select2-container:first").children(".selection:first").children(".select2-selection:first").removeClass("error").removeClass(" form-control");
		 
		$(validator.currentElements[i]).parents(".form-group:first").children(".select2-container:first").children(".selection:first").children(".select2-selection:first").qtip("destroy",true);
		$(validator.currentElements[i]).qtip("destroy",true);
		//$(validator.currentElements[i]).removeData("hasqtip");
		//$(validator.currentElements[i]).removeAttr("data-hasqtip");
	}
	

	var qTipConfiguration = {
			suppress: false,
			content: {
				text: ""
			},
			position: {
				my: 'top center',
				at: 'bottom, center'
			},
			show: {
				event: 'mouseover'
			},
			style: {
				classes: 'qtip-red qtip-rounded'
			}
		}
	
	//Add qtips for elements which has errors
	for(var i = 0 ; i < validator.errorList.length; i++){	
		
		qTipConfiguration.content.text = validator.errorList[i].message
		
	
		//This is to handle UI for error for the select2 related divs
		$(validator.currentElements[i]).parents(".form-group:first").children(".select2-container:first").children(".selection:first").children(".select2-selection:first").addClass("error").addClass(" form-control");
		$(validator.currentElements[i]).parents(".form-group:first").children(".select2-container:first").children(".selection:first").children(".select2-selection:first").qtip(qTipConfiguration);
		
		$(validator.errorList[i].element).parents(".form-group:first").addClass("has-error");
		$(validator.errorList[i].element).qtip(qTipConfiguration);			
		
	}
	
	showModal('Please correct the errors in the input', MODAL_TYPE_ERROR, ["Ok"], ["hideOverlay"]);
}


function showModal(message, type, buttonName, callBackFunction){
	
	var modalClass = "";
	
	if(type == MODAL_TYPE_INFO){
		modalClass = "modal-info";
		buttonClass = "btn-outline";
	} else if(type == MODAL_TYPE_ERROR){
		modalClass = "modal-danger";
		buttonClass = "btn-outline";
		var buttonColour = "red";
	} else if(type == MODAL_TYPE_SUCCESS){
		modalClass = "modal-success";
		buttonClass = "btn-outline";
	} else if(type == MODAL_TYPE_WARNING){
		modalClass = "modal-warning";
		buttonClass = "btn-outline";
	} else {
		modalClass = "modal-default";
		buttonClass = "";
	}
	
	var modalContent = '';
	modalContent += '<div class="modal '+modalClass+' fade in" id="int-modal">';
	modalContent += '<div class="modal-dialog">';
	modalContent += '  <div class="modal-content">';
	modalContent += '    <div class="modal-header">';
	if(!Array.isArray(callBackFunction)){
		modalContent += '      <button type="button" class="close" data-dismiss="modal" aria-label="Close">';
		modalContent += '        <span aria-hidden="true">&times;</span></button>';
	}
	
	modalContent += '      <h4 class="modal-title">Alert</h4>';
	modalContent += '    </div>';
	modalContent += '    <div class="modal-body">';
	modalContent += '      <p>'+message+'</p>';
	modalContent += '    </div>';
	modalContent += '    <div class="modal-footer">';
	
	if(Array.isArray(callBackFunction)){
		var isFirst=true;
		for(var i=0;i<callBackFunction.length;i++) {
			if(isFirst){
				modalContent += '      <button type="button" style="background-color:'+buttonColour+';" class="btn '+buttonClass+' pull-left" data-dismiss="modal" id="modalok" onclick="'+callBackFunction[i]+'();">'+buttonName[i]+'</button>';
				isFirst = false;
			} else {
				modalContent += '      <button type="button" class="btn '+buttonClass+' pull-right" data-dismiss="modal" id="modalok" onclick="'+callBackFunction[i]+'();">'+buttonName[i]+'</button>';
			}
		}
	} else {
		modalContent += '      <button type="button" class="btn '+buttonClass+' pull-left" data-dismiss="modal" id="modalok" onclick="'+callBackFunction+'">Ok</button>';
	}
	modalContent += '    </div>';
	modalContent += '  </div>';
	modalContent += '</div>';
	modalContent += '</div>  <button style="display:none;"id="buttonop" type="button" class="btn btn-info btn-lg" data-target="#int-modal">Open Modal</button>';
		
	$('#int-modal-content').html(modalContent);
	$("#buttonop").click(function(){
		if(Array.isArray(callBackFunction)) {
			$("#int-modal").modal({
	            backdrop: 'static'
	        });
		} else {
			$("#int-modal").modal();
		} 
    });
	
	$('#buttonop').trigger("click");
	$('#modalok').focus();

}

function showOverlay() {
	if($(".overlay").length != 0 ) {
		$(".overlay").show();
	}
} 
function hideOverlay() {
	if($(".overlay").length != 0 ) {
		$(".overlay").hide();
	}
}

function networkCheck() {
	if($("#testId").val() != SAMPLE_TEST_DEFAULT_ID){
	var sectionTime = getSectionTime();
	if(sectionTime == undefined) {
		sectionTime = "";
	}
	/*if(navigator.onLine) {*/
		$.ajax({
			method : "get",
			url:CONTEXT_PATH+"/guest/networkCheck?sectionTime="+sectionTime,
			timeout : 5000,
			complete : function(xhr, status) {
				if(status == "success") {
					var stopCounter = setTimeout(function(){
						networkCheck();
					}, 10000);
				} else if (status == "error" || status == "timeout") {
					$(".fa-wifi").css("color","red");
					showModal("Please check network connection! </br> If disconnected, please connect within "+NETWORK_RECONNECT_TIME+" secs and <b style='color:red;'>REFRESH THE BROWSER</b></br> Other wise application will get disconnected",MODAL_TYPE_WARNING,['Ok'],['startCounter']);
					//$("#count").html(convertSecToMin(NETWORK_RECONNECT_TIME));
					clearTimeout(stopSectionTimer);
					clearTimeout(stopQuestionTimer);
				}
			}
		});
	/*} else {
		$(".fa-wifi").css("color","red");
		showModal("Please check Network connection! </br> If disconnected, connect withinin 30 sec and <b style='color:red;'>REFRESH BROWSER</b></br> Other wise Application will disconnected",MODAL_TYPE_WARNING,['Ok'],['startCounter']);
		$("#count").html("00:30");
		
	}*/
	}	
}

function count(time) {
	var presentTime = time;
	var timeArray = presentTime.split(/[:]+/);
	var m = timeArray[0];
	var s = checkSecond((timeArray[1] - 1));

	if (s == 59) {
		m = m - 1
		if(m < 10) {
			m = "0"+m;
		}
	}
	var time = m + ":" + s;
	$("#count").html(time);
	 
	
	if (m == 0 && s == 0) {
		$("#count").hide();
		flag = false;
		clearTimeout(stopCounter);
		showModal("Apllication was Disconnected" ,MODAL_TYPE_INFO);
	}
		
	stopCounter = setTimeout(function(){
		count(time)
	}, 1000);
	
}

function checkSecond(sec) {
	if (sec < 10 && sec >= 0) {
		sec = "0" + sec;
	}
	if (sec < 0) {
		sec = "59";
	}
	return sec;
}

function startCounter() {
	
	$("#count").show();
	count(convertSecToMin(NETWORK_RECONNECT_TIME));
}

/*function sessionClose() {
	'<%session.setAttribute("sessionUserObj",null); %>';
	'<%session.setAttribute("testInstance",null); %>';
}*/