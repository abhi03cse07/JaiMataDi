<?php include 'cardframe_start.php'; ?>
<h4 class="card-title appnamestyle">
<i class="fa fa-server iconsize pb-1 <?php echo $iconcolor; ?>"></i> <br><br>Assets</h4>
<p class="card-text appdescstyle">Track & manage IT Assets & devices</p>
<a class="dwllink" href="//apps.myimss.work/assets" target="_blank">
<i class="fas fa-external-link-alt"></i> &nbsp; Open App</a>&nbsp;</a>
<?php include 'cardframe_end.php'; ?>
