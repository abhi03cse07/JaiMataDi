<?php
    $slide1_img="http://www.myimss.work/apps/scoop/archives/img_myimss.work_apps_scoop_carousel_".$version."_slide_1.jpg";
    $slide2_img="http://www.myimss.work/apps/scoop/archives/img_myimss.work_apps_scoop_carousel_".$version."_slide_2.jpg";
    $slide3_img="http://www.myimss.work/apps/scoop/archives/img_myimss.work_apps_scoop_carousel_".$version."_slide_3.jpg";
    $slide1_h3="Access new website at imss.work";
    $slide1_p="The journey with IMSS to digital transformation just got wee bit clearer !";
    $slide2_h3="Share feedback on the new website";
    $slide2_p="Share your ideas, opinions and suggestions at anil@integramicro.com";
    $slide3_h3="Happy Ganesh Chaturdi";
    $slide3_p="May lord Ganapathi bless you, with the treasure of Health, Wealth and Happiness...";
    //$slide1_bg="rgba-black-light";
    //$slide2_bg="rgba-black-slight";
    $slide1_bg="rgba-black-strong";
    $slide2_bg="rgba-black-strong";
    $slide3_bg="rgba-black-light";
    include 'includes/modules/carousel-tunein.php';
    $module_heading="Updates and Announcements";
    include 'includes/modules/module-heading.php';
?>
<div class="row">
<div class="card-columns">

    <!--Panel-->
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Bhuvaneshwari K S</h5>
            <p class="card-text">Won two awards from SRIB and Samsung electronics HQ for SSM development projects.</p>
            <img src="http://www.myimss.work/apps/people/profilepic/13000.jpg" style="max-width:95%;">
        </div>
    </div>
    <!--/.Panel-->

    <!--Panel-->
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Gaurav Gupta</h5>
            <p class="card-text">Appreciated and recognized for Spot Award towards tremendous contribution and hard work at Samsung.</p>
            <img src="http://www.myimss.work/apps/people/profilepic/13155.jpg" style="max-width:95%;">
        </div>
    </div>
    <!--/.Panel-->

    <!--Panel-->
    <div class="card bg-primary text-white text-center p-3">
        <blockquote class="blockquote mb-0">
            <p>The i'Manage app is available for download at the below link.</p>
            <footer class="blockquote-footer">
            <a href="http://www.myimss.work/apps/manage/iManage.apk">
                <small style="color:#ffffff;">
                Click here <cite title="Source Title">to download the .APK file</cite>
                </small>
                </a>
            </footer>
        </blockquote>
    </div>
    <!--/.Panel-->

    <!--Panel-->
    <div class="card text-center">
        <div class="card-body">
            <h5 class="card-title">Did you know ?</h5>
            <p class="card-text">IMSS is now registered with GeM (Government eMarketplace).</p>
            <p class="card-text"><small class="text-muted">This can help us increase our visibility across India in the central and state governments, without the need to go through middle agencies, NIC or NICSI.</small></p>
            <img src="http://files.imss.work/logos/partners/logo_partner_gem.png" style="max-width:95%;">
        </div>
    </div>
    <!--/.Panel-->

    <!--Panel-->
    <div class="card p-3 text-right">
        <blockquote class="blockquote mb-0">
            <p>Notable days in September</p>
            <footer class="blockquote-footer">
                <small class="text-muted">
                <cite title="Source Title">Sep 08</cite> World Literacy Day <br>
                <cite title="Source Title">Sep 12</cite> Ganesh Chaturdi <br>
                <cite title="Source Title">Sep 15</cite> International Engineers Day <br>
                <cite title="Source Title">Sep 21</cite> World Peace Day <br>
                <cite title="Source Title">Sep 27</cite> World Tourism Day <br>
                <cite title="Source Title">Sep 29</cite> World Heart Day <br>
                </small>
            </footer>
        </blockquote>
    </div>
    <!--/.Panel-->

</div>
</div>
