<?php include 'cardframe_start.php'; ?>
<h4 class="card-title appnamestyle">
<i class="<?php echo $iconcolor; ?> fa fa-hands-helping iconsize pb-1"></i> <br><br>Helpdesk</h4>
<p class="card-text appdescstyle">Email HR / Finance at <a href="mailto:people@imss.work?subject=[HR HELPDESK] &body=[HELPDESK] DO NOT REMOVE THE WORD [HELPDESK] FROM SUBJECT AND BODY WHILE SENDING EMAIL."
    target="_blank">
    &nbsp; people@imss.work</a>&nbsp;</a></p>
</p>
<a class="dwllink" href="mailto:people@imss.work?subject=[HELPDESK] &amp;body=[HR HELPDESK] DO NOT REMOVE THE WORD [HR HELPDESK] FROM SUBJECT AND BODY WHILE SENDING EMAIL."
target="_blank">
<i class="far fa-envelope"></i> &nbsp; Send Email</a>
<?php include 'cardframe_end.php'; ?>
